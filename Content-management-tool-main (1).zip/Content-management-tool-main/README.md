<h1 align="center">
  <a href="# Content Management Tool"></a>
  Content Management Tool
</h1>

## `Project Title`
Content Management Tool

## `Description`
Content Management Tool is a web-based content management system developed as Task 1 for the **Bharat Intern** internship program. It allows users to manage and publish contents easily. It allows users to add text, images and videos required to create a blog. 

## `Tech Stack Used`
<li>HTML</li>
<li>CSS</li>
<li>JavaScript</li>

## `Installation`
<li>Clone the repository: git clone https://github.com/Shivakant090/Content-management-tool.git </li>
<li>Open the project folder in your preferred code editor.</li>
<li>Open the content-management-tool.html file in a web browser.</li>
